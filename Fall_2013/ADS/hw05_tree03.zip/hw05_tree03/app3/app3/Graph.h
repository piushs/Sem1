#pragma once
#include "Interfaces05.h"

class Graph : public IGraph
{
public : 
  std :: vector <IVertex *> graph;
  int max;
  std :: vector <int> min_vec_1;
  Graph() 
  { 
	max = -1;
  }
  ~Graph() { }
  IVertex * insertVertex(std::string name);
  void handle_vertex(std :: string name, int *max_val, std :: vector <int> &min_vec);
  std::vector<IVertex *> getVertices();
};