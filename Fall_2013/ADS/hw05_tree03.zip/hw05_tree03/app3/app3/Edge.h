#pragma once
#include "Interfaces05.h"

class Edge : public IEdge {

public :
  IVertex *target;
  int weight;

  Edge() { }
  ~Edge() { }
  IVertex * getTarget();
  void setTarget(IVertex * target);
  int getWeight();
  void setWeight(int value);
};