#include "Graph.h"
#include "Vertex.h"
#include "Edge.h"

bool find_overlap(std :: string str1, std :: string str2, int *pos, int *max)
{
	/*
	int index=0;
	while (1)
	{
		int search = str2.find(str1.substr(0, str1.size() - index));
		if ( search != std :: string :: npos || index == str1.size())
		{
			*pos = str1.size() - index;
			
			if (*max < *pos)
				*max = *pos;

			return(true);
		}
		index ++;
	} */

	int index=0;
	int bck;
	int first = 0;
	while (1)
	{
		int search = str2.find(str1.substr(0, str1.size() - index));
		if ( search != std :: string :: npos || index == str1.size())
		{
			*pos = str1.size() - index;
			
			if (*max < *pos)
				*max = *pos;

			return(true);
		}/*
		if (first == 0)
		{
			bck = index;
			index = str1.size()/2;
			search = str2.find(str1.substr(0, str1.size() - index));
			if (search != std :: string :: npos)
			{
				index = index - index/2;
				search = str2.find(str1.substr(0, str1.size() - index));
				if (search != std :: string :: npos)
				{
					index = bck;
					index ++;
				}
			}
			else
			{
				bck = index;
				index = index + index/2;
				search = str2.find(str1.substr(0, str1.size() - index));
				if (search != std :: string :: npos)
				{
					index = bck;
					index ++;
				}
			}

			first = 1;
		}
		else */
			index ++;
	}

	return(false);
}


IVertex * Graph :: insertVertex(std::string name)
{
	IVertex *node = new Vertex();
	node->setName(name);
	
	int pos = -1;

	for (int i=0; i<graph.size(); i++)
	{
		IEdge *edge = new Edge();
		
		find_overlap(node->getName(),graph[i]->getName(),&pos, &max);
		if (pos != 0)
		{
			edge->setTarget(node);
			edge->setWeight(pos);
			graph[i]->addEdge(edge);
		}

		if (min_vec_1[i] > pos)
			min_vec_1[i] = pos;

		IEdge *edge1 = new Edge();
		
		find_overlap(graph[i]->getName(), node->getName(), &pos, &max);
		if (pos != 0)
		{
			edge1->setTarget(graph[i]);
			edge1->setWeight(pos);
			node->addEdge(edge1);
		}
	}
	
	graph.push_back(node);

	if (pos != -1)
		min_vec_1.push_back(pos);
	else
		min_vec_1.push_back(1001);

	return(node);
}

void Graph :: handle_vertex (std :: string name , int *max_val, std :: vector <int > &min_vec)
{
   insertVertex(name);
   *max_val = max;
   min_vec = min_vec_1;
}

std::vector<IVertex *> Graph :: getVertices()
{
	return (graph);
}