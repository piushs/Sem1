#include "Edge.h"

IVertex * Edge :: getTarget()
{
	return(target);
}

void Edge :: setTarget(IVertex * target_val)
{
	target = target_val;
}

int Edge :: getWeight()
{
	return weight;
}

void Edge :: setWeight(int value)
{
	weight = value;
}
