#pragma once

#include "Interfaces05.h"
#include "Graph.h"

class TSPNode
{
public :
	TSPNode () {};
	~TSPNode () {};
	std :: vector < IVertex * >  path;
	int bound;
};




class Sequencer : public ISequencer 
{
public:
	Graph *grapher;
	std :: vector <int > min_vec;
	
  Sequencer() { 
  grapher = new Graph(); }
  ~Sequencer() { }
  IGraph * buildGraph(std::vector<std::string>& reads);
  std::vector<std::string> tsp(std::string start_read, IGraph * graph);
  std::string assemble(std::vector<std::string>& tsp_result);
  std::vector<std::string> tspComplete(IGraph * graph);
};