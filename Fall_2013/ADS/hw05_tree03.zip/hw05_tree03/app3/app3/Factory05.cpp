#include "Factory05.h"
#include "Sequencer.h"
#include "Vertex.h"
#include "Edge.h"
#include "Graph.h"

Factory05::Factory05()
{
}

Factory05::~Factory05()
{
}
 
void * Factory05::create(std::string name)
{
  if(name == "ISequencer"){
    return new Sequencer();
  } else if(name == "IGraph"){
    return new Graph();
  } else if(name == "IVertex"){
    return new Vertex();
  } else if(name == "IEdge"){
    return new Edge();
  } else {
    return NULL;
  }
}

extern "C" {

ObjectFactory * createObjectFactory(){
  return new Factory05();  
}

}
