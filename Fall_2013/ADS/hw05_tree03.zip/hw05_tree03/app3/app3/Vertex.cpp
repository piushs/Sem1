#include "Vertex.h"

void Vertex :: setName(std::string name)
{
	node = name;
}

std::string Vertex :: getName()
{
	return(node);
}

void Vertex :: addEdge(IEdge * edge)
{
	target.push_back(edge);
}


std::vector<IEdge *> Vertex :: getEdges()
{
	return(target);
}