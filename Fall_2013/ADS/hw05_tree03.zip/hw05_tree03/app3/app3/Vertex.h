#pragma once
#include "Interfaces05.h"

class Vertex : public IVertex
{
public : 
  std :: string node;
  std :: vector<IEdge *> target;
 
  Vertex() 
  { 
	
  }
  ~Vertex() { }
  void setName(std::string name);
  std::string getName();
  void addEdge(IEdge * edge);
  std::vector<IEdge *> getEdges();
};