#include "Queue.h"

void Queue :: push (TSPNode *node)
{
	elements.push_back(node);
	fixup();
}

void Queue :: pop ()
{
	fixdown();
}

void Queue :: fixup ()
{
	int parent = (elements.size()/2) - 1;
	int child = elements.size () - 1;
	TSPNode *swap;

	while (parent >= 0)
	{
		if (elements[child]->bound < elements[parent]->bound)
		{
			swap = elements[parent];
			elements[parent] = elements[child];
			elements[child] = swap;
		}
		else if (elements[child]->bound == elements[parent]->bound)
		{
			if (elements[child]->path.size() > elements[parent]->path.size())
			{
				swap = elements[parent];
				elements[parent] = elements[child];
				elements[child] = swap;
			}
		}

		child--;
		if (((child+1)/2-1)!= parent)
		{
		    child=parent;
			parent=(child+1)/2-1;
		}
	}
}

void Queue :: fixdown ()
{
	elements[0] = elements[elements.size() - 1];

	TSPNode *replace = new TSPNode();
	TSPNode *swap = new TSPNode();
	
	elements.pop_back();

	int top=0;
	int child1=(2*top +1);
	int child2=(2*top+2);
	int index;

	while (child1 < elements.size() || child2 < elements.size())
	{
		if (child1 < elements.size() && child2 >= elements.size())
		{
			index = child1;
			replace = elements[child1];
		}
		else if (child2 < elements.size() && child1 >= elements.size())
		{
			index = child2;
			replace = elements[child2];
		}
		else if (elements[child1]->bound < elements[child2]->bound)
		{
			index = child1;
			replace = elements[child1];
		}
		else if  (elements[child1]->bound > elements[child2]->bound)
		{
			index = child2;
			replace = elements[child2];
		}
		else
		{
			if (elements[child1]->path.size() > elements[child2]->path.size())
			{
				index = child1;
				replace = elements[child1];
			}
			else
			{
				index = child2;
				replace = elements[child2];
			}
		}

		if (replace->bound < elements[top]->bound)
		{
			swap = replace;
			elements[index] = elements[top];
			elements[top] = swap;
			top = index;
		}
		else if (replace->bound  == elements[top]->bound)
		{
			if (elements[top]->path.size() < replace->path.size())
			{
				swap = replace;
				elements[index] = elements[top];
				elements[top] = swap;
				top = index;
			}
		}
		child1 = 2*index+1;
		child2 = 2*index+2;
	}
}

bool Queue :: empty()
{
	if (elements.size() == 0)
		return (true);

	return(false);
}

TSPNode * Queue :: top ()
{
	return (elements[0]);
}