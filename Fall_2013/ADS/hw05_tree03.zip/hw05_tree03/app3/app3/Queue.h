#pragma once
#include "Sequencer.h"

class Queue 
{
public :
	std :: vector <TSPNode *> elements;
	void push (TSPNode *node);
	void pop ();
	void fixup();
	void fixdown();
	bool empty();
	TSPNode * top();
};

