#include "Sequencer.h"
#include <iostream>
#include "Queue.h"
#include <climits>


class hashcode
{
public :
	int key;
	std :: string str;
};

IGraph * Sequencer :: buildGraph(std::vector<std::string>& reads)
{

	std :: vector < std :: string > res;
	std :: vector <hashcode> val;
	std :: vector<int> store;

	int i,j;
	/*
	for (int i=0 ; i<600 ; i++)
	{
		hashcode v;
		v.key = -1;
		val.push_back(v); 
	}

	for (int i=0; i<reads.size() ; i++)
	{
		int x = 0;
		int k = -1;
		
		for (int j=reads[i].size() - 1; j>= 0; j--)
		{
		    x  = x + k * ((int) reads[i][j] - 'a');
			k= k+3;
			k = k%11;
		}
		
		if (val [x].key == -1)
		{
			val[x].key = x;
			val[x].str = reads[i];
			res.push_back(reads[i]);
			store.push_back(x);
		}
	}
	*/
	
		
	for (i=0 ; i<reads.size() ; i++)
	{
		for (j =0 ; j<res.size () ; j++)
		{
			if (reads[i].compare(res[j]) == 0)
				break;
		}
		if (j == res.size())
		{
			res.push_back(reads[i]);
		}
	}

	
	int max;
	
	for (i =0; i<res.size() ; i++)
	{
		IVertex *node;
		grapher->handle_vertex(res[i], &max, min_vec);
	}

	for (i =0 ; i<grapher->getVertices().size() ; i++)
	{
		for (int j=0; j<grapher->getVertices()[i]->getEdges().size(); j++)
		{
			grapher->getVertices()[i]->getEdges()[j]->setWeight(max - grapher->getVertices()[i]->getEdges()[j]->getWeight());
		}
	}
	return(grapher);
}

IVertex * search_vertex (std :: string start_read, IGraph *graph)
{
	
	for (int i = 0 ; i < graph->getVertices().size(); i++)
	{
		if (start_read.compare(graph->getVertices()[i]->getName()) == 0)
		{
			return(graph->getVertices()[i]);
		}
	} 
}

bool check_edge_in_path (IEdge *edge, std :: vector <IVertex *> path)
{
	for (int i =0 ; i< path.size() ; i++)
	{
		if (edge->getTarget()->getName().compare(path[i]->getName()) == 0)
			return(true);
	}
	return(false);
}

bool check_all_elements (std :: vector <IVertex *> path, IGraph *graph)
{
	/*
	int i, count;
	for ( i = 0 , count = 0; i < graph->getVertices().size(); i++)
	{
		for (int j=0; j< path.size(); j++)
		{
			if (path[j]->getName().compare(graph->getVertices()[i]->getName()) == 0)
			{
				count ++;
				break;
			}
		}
	}

	if (count == i)
		return(true);

	return(false); */
	if (path.size () == graph->getVertices().size())
		return (true);

	return(false);
}

int get_min (std :: vector <IEdge *> edges)
{
	int min = INT_MAX;
	/*
	for (int i =0 ; i < edges.size() ; i++)
	{
		if (min > edges[i]->getWeight())
			min = edges[i]->getWeight();
	} */


	return(min);
}

int other_Bound (std :: vector <IVertex *> path, IGraph *graph, std :: vector <int> & min_vec)
{
   int ret = 0;

   for (int i=path.size(); i< graph->getVertices().size() ; i++)
   {
	 //  for (int j=0 ; j<path.size(); j++)
	   {
		//   if (graph->getVertices()[i]->getName().compare(path[j]->getName()) != 0)
		   {
			   int min_edge_weight = min_vec[i];//get_min(graph->getVertices()[i]->getEdges());
			   ret = ret + min_edge_weight;
		   }
	   }
   }

   return (ret);
}

std::vector<std::string> Sequencer :: tsp(std::string start_read, IGraph * graph)
{
	IVertex *vertex = search_vertex(start_read, graph);

	TSPNode *node = new TSPNode ();
	node->path.push_back(vertex);
	node->bound = 0;
	int min_bound = INT_MAX;
	Queue *min_queue = new Queue ();
	min_queue->push(node);

	std :: vector <std :: string > min_path;
	
	while (min_queue->empty() == false)
	{
		TSPNode * curr = min_queue->top ();

		min_queue->pop();

		int curr_bound = curr->bound;
		int other_bound = other_Bound (curr->path, graph,min_vec);

		if (curr_bound + other_bound < min_bound)
		{
			IVertex *last = curr->path[curr->path.size() - 1];

			for (int j=0 ; j < last->getEdges().size() ; j++)
			{
				if (check_edge_in_path(last->getEdges()[j], curr->path) == false)
				{
					TSPNode *new_path = new TSPNode();
					new_path->path = curr->path;
					new_path->path.push_back(last->getEdges()[j]->getTarget()); 
					new_path->bound = curr->bound + last->getEdges()[j]->getWeight();
					

					if (check_all_elements (new_path->path, graph) == true)
					{
						int new_bound = curr->bound + last->getEdges()[j]->getWeight();
						new_path->bound = new_bound;

						if (new_bound < min_bound)
						{
							min_bound = new_path -> bound;

							for (int k=0; k<new_path->path.size() ; k++)
							{
								min_path.push_back(new_path->path[k]->getName()) ;
							}
							min_path .push_back(start_read);
						}
						
					//	return (min_path);
					}
					else
					{
						min_queue->push(new_path);
					}
				}
			}

		}
	}
	
	return (min_path);
}

std::string Sequencer :: assemble(std::vector<std::string>& tsp_result)
{
	std :: string res;
	res = tsp_result[0];
	for (int i=0; i<tsp_result.size()-1 ; i++)
	{
		int index=0;
		while (1)
		{
			int found = tsp_result[i].find(tsp_result[i+1].substr(0,tsp_result[i+1].size()-index));
			
			if (found != std :: string :: npos)
			{
				std :: string str2 = tsp_result[i+1].substr(0, tsp_result[i+1].size()-index);
				std :: string str1 = tsp_result[i].substr(tsp_result[i].size() - str2.size(),str2.size());
				
				if ( str1 == str2 )
				{
					//res.append(tsp_result[i+1].substr(tsp_result[i+1].size()-index,tsp_result[i+1].size()));
					res.append(tsp_result[i+1].substr(str2.size(), tsp_result[i+1].size () - str2.size()));
					int len = res.size();
					break;
				}
			}
			index ++;
		}
	}
	return (res);
}

std::vector<std::string> Sequencer :: tspComplete(IGraph * graph)
{
	std :: vector < std :: string > vec;
	return(vec);
}
