#include "PriorityQueue1.h"
#include "VectorKeyValue.h"
#include "KeyValue.h"
#include "VectorString.h"
#include <iostream>

void PriorityQueue1 :: merge (IPriorityQueue * input_queue)
{
	std :: cout << "";
}

void PriorityQueue1 :: enqueue (IKeyValue  * key_value)
{
	int found=0;
	KeyValue *temp_ptr;
	
	KeyValue *node = new KeyValue();
	KeyValue *prev = new KeyValue();

	KeyValue *node1 = new KeyValue();
		
	temp_ptr=(KeyValue*) key_value;
	node->key=temp_ptr->getKey();
	node->value=temp_ptr->getValue();

	node1=(KeyValue*)key_value;
	node1->key=temp_ptr->getKey();
	node1->value=temp_ptr->getValue();
	prev=head;	
	if (firsttime == 0)
	{
		node->nextelement=NULL;
		node->prevelement=NULL;
		
		head=node;

		firsttime=1;
	//	sort->push_back(node1);
		track->push_back(key_value->getValue());
		queue_size ++;
		int div=key_value->getKey()/2;
        addr[div]=node;
	}
	else
	{
		int div=key_value->getKey()/2;

		if (addr[div] == NULL)
		{
		   addr[div]=node;
		   div--;
		   while (addr[div] == NULL && div >=0)
		   {
			   div--;
		   }
		   if (div >= 0)
			   temp_ptr=addr[div];
		   else
			   temp_ptr=head;
		}
		else
		{
		   if (addr[div]->getKey() <= key_value->getKey())
			   temp_ptr=addr[div];
		   else
		   {
			   div--;
		       while (addr[div] == NULL && div >=0)
		       {
			      div--;
		       }
		       if (div >= 0)
			       temp_ptr=addr[div];
		       else
			       temp_ptr=head;
		   }
		}
		
		
		while (temp_ptr != NULL && found == 0)
		{
			if (temp_ptr->getKey() == key_value->getKey())
			{
				found=1;
				if (temp_ptr == head)
				{
					track->push_back(key_value->getValue());
				}
				break;
			}
			if (temp_ptr->getKey() > key_value->getKey())
			{
				break;
			}
			prev=temp_ptr;
			temp_ptr=temp_ptr->nextelement;
		}
		if (found == 0)
		{
			if (temp_ptr != NULL)
			{
				if (temp_ptr != head)
				{
					node->nextelement=prev->nextelement;
					prev->nextelement=node;
					node->prevelement=prev;
				}
				else
				{
					node->nextelement=prev;
					node->prevelement=NULL;
					prev->prevelement=node;
					head=node;
					
					track->vssize=0;
					track->push_back(key_value->getValue());
				}
			}
			else
			{
				node->nextelement=prev->nextelement;
				prev->nextelement=node;
				node->prevelement=prev;
			}
			queue_size ++;
		}
	}
	sort->push_back(node1);
}


IVectorKeyValue * PriorityQueue1 :: returnSorted()
{
	/*
	VectorKeyValue *temp_ptr=new VectorKeyValue();
	
	temp_ptr=sort;
	if (firsttraverse==0)
	{
		traverse=sort->vkvalue;
		firsttraverse=1;
	}
	if ((sort->vksize-1)/100 >1)
	{
		for (int i=0; i<100;i++)
			traverse=traverse->nextelement;
		temp_ptr->vkvalue=traverse;
	}
	else if (sort->vksize == 101)
	{
		//traverse=traverse->nextelement;
		temp_ptr->vkvalue=traverse;
	}
	else if (sort->vksize == 1)
	{
		temp_ptr->vkvalue=traverse;
	}*/

	return sort;
}

int  PriorityQueue1 :: lowestKey ()
{
	return head->getKey();
}

IVectorString * PriorityQueue1 :: lowestValues()
{
	return(track);
}

void PriorityQueue1 :: dequeue ()
{
	head=head->nextelement;
	track=new VectorString();
    int tempvar=0;
	int i=0;
	track->vssize=0;
	KeyValue *temp=new KeyValue();
	temp=sort->vkvalue;
	while (temp != NULL && temp->getKey() == start)
	{
		i++;
		temp=temp->nextelement;
	}
	if (temp != NULL)
	{
		start=temp->getKey();
		tempvar=i;
		KeyValue *temp1 = new KeyValue();
		temp1=temp;
		while (temp1 != NULL && temp1->getKey() == start)
		{
			track->push_back(temp1->getValue());
			temp1=temp1->nextelement;
			i++;
		}
	}	
	queue_size--;
	
	sort->vkvalue=temp;
	
	for (int j=0; j< tempvar ;j++)
		sort->pop_back();
}

size_t PriorityQueue1 :: size ()
{
	return queue_size;
}