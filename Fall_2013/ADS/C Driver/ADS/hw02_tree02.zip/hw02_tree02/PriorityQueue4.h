#pragma once

#include "Interfaces02.h"
#include "KeyValue.h"
#include "VectorKeyValue.h"
#include "VectorString.h"

class Element 
{

public:
	Element ()
	{
		linkno=0;
		for (int i=0 ; i < 20;i++)
			link[i]=NULL;
	}
	~Element() {}
	int key;
	Element *right;
	std :: string value;
	int linkno;
	Element *link[20];
};

class PriorityQueue4 : public IPriorityQueue
{

public :

	Element *head,*tail;
	int queue_size;
	Element *min;
	VectorString *strval;
	PriorityQueue4() 
	{
		head=NULL;
		queue_size=0;
		strval=new VectorString();
	};
    ~PriorityQueue4() {};

	void enqueue(IKeyValue * key_value);
	void merge(IPriorityQueue * input_queue);
	int lowestKey();
	IVectorString * lowestValues();
    void dequeue();
	size_t size();
	IVectorKeyValue* returnSorted();
};