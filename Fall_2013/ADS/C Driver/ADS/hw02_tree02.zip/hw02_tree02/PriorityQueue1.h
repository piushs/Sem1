#pragma once

#include "Interfaces02.h"
#include "KeyValue.h"
#include "VectorKeyValue.h"
#include "VectorString.h"


class PriorityQueue1 : public IPriorityQueue
{

public :
	KeyValue *head,*tail;
	KeyValue *addr[10000];
	size_t queue_size;
	VectorString *track;
	int firsttime,start,end;
	VectorKeyValue *sort;
	KeyValue *traverse;
	int firsttraverse;
	int counter;
	PriorityQueue1() 
	{ 
		
		queue_size =0; 
		head=NULL;
		start=0;
		firsttime=0;
		sort=new VectorKeyValue();
		track=new VectorString();
		for (int i=0; i<10000; i++)
			addr[i]=NULL;
		traverse=new KeyValue();
		firsttraverse=0;
	};
    ~PriorityQueue1() {};

	void enqueue(IKeyValue * key_value);
	void merge(IPriorityQueue * input_queue);
    IVectorKeyValue* returnSorted();
	int lowestKey();
	IVectorString * lowestValues();
    void dequeue();
	size_t size();
};