#include "PriorityQueue3.h"
#include "VectorKeyValue.h"
#include "KeyValue.h"
#include "VectorString.h"
#include <iostream>

void PriorityQueue3::sort ()
{
	int i,j;
	Node *temp=new Node ();
	for ( i=0;i<stack_size;i++)
	{
		for ( j=i+1;j<stack_size;j++)
		{
			if (stk[i]->linkno < stk[j]->linkno)
			{
				temp=stk[i];
				stk[i]=stk[j];
				stk[j]=temp;
			}
			else if (stk[i]->linkno == stk[j]->linkno)
			{
				if (stk[i]->key < stk[j]->key)
				{
					temp=stk[i];
					stk[i]=stk[j];
					stk[j]=temp;
				}
			}

		}
	}
}

void PriorityQueue3::sort1 (Node *stack[20], int top)
{
	for (int i=0;i<top-1;i++)
	{
		for (int j=i+1;j<top;j++)
		{
			if (stack[i]->linkno < stack[j]->linkno)
			{
				Node *temp=new Node ();
				temp=stack[i];
				stack[i]=stack[j];
				stack[j]=temp;
			}
			else if (stack[i]->linkno == stack[j]->linkno)
			{
				if (stack[i]->key < stack[j]->key)
				{
					Node *temp=new Node ();
					temp=stack[i];
					stack[i]=stack[j];
					stack[j]=temp;
				}
			}

		}
	}
}

void PriorityQueue3 :: merge (IPriorityQueue * input_queue)
{
	PriorityQueue3 *temp_ptr=new PriorityQueue3();
	temp_ptr=(PriorityQueue3*) input_queue;

	for (int k=0; k<temp_ptr->stack_size; k++)
	{
		stk[stack_size++]=temp_ptr->stk[k];
	}

	sort();

	Node *save[20];
	int save_size=0;
	int i=stack_size-1;
	int work=0;
	do
	{
		work=0;
		i=stack_size-1;
		save_size=0;
		while ( i>0 )
		{
			if (stk[i]->linkno==stk[i-1]->linkno)
			{
				work=1;
				stk[i]->link[stk[i]->linkno++]=stk[i-1];
				save[save_size++]=stk[i];
				i=i-2;
			}
			else
			{
				save[save_size++]=stk[i];
				i--;
			}
		}
		if (i==0)
			save[save_size++]=stk[i];
		stack_size=0;
		for (int j=save_size-1;j>=0;j--)
		{
			stk[stack_size++]=save[j];
		}
		sort();
	}while (work==1);

	for (int i=0; i<stack_size-1;i++)
	{
		stk[i]->right=stk[i+1];
		stk[i+1]->left=stk[i];
	}
	stk[stack_size-1]->right=NULL;
	stk[0]->left=NULL;
	if (stack_size>=0)
	head=stk[0];

	queue_size=queue_size+temp_ptr->queue_size;
}

void PriorityQueue3 :: enqueue (IKeyValue  * key_value)
{
	Node *node = new Node();
	Node *temp = new Node();
	node->key=key_value->getKey();
	node->value=key_value->getValue();
	node->right=NULL;
	node->linkno=0;
	node->left=NULL;
	
	int flag=0;
	for (int i=stack_size-1; i>=0; i--)
	{
	    if(stk[i]->linkno == node->linkno)
		{
			flag=1;
			temp = stk[i];

			if (temp->key > node->key)
			{ 
				node->link[node->linkno++]=temp;
				stk[i]=node;
			}
			else
			{
				temp->link[temp->linkno++]=node;
				stk[i]=temp;
			}
			node=stk[i];
			stack_size--;
		}
		else
		{
			break;
		}
	}

	if (flag == 0)
	{
		stk[stack_size]=node;
		stack_size++;
	}
	else 
		stack_size++;

	for (int i=0;i<stack_size-1;i++)
	{
		stk[i]->right=stk[i+1];
		stk[i+1]->left=stk[i];
	}
	stk[stack_size-1]->right=NULL;
	stk[0]->left=NULL;
	queue_size++;
}


IVectorKeyValue * PriorityQueue3 :: returnSorted()
{
	return NULL;
}

int  PriorityQueue3 :: lowestKey ()
{
	int min;
	if (flag == 0)
	{
		min = stk[stack_size-1]->key;
		strvalue->vssize=0;
		int k;
		for (int i=stack_size -1; i>=0; i--)
		{
			if (min >= stk[i]->key)
			{
				min =stk[i]->key;
				pos=i;
				k=i;
			}
		}
		strvalue->vssize=0;
		strvalue->push_back(stk[k]->value);
	}
	else
	{
		Node *temp_ptr = new Node();
	    min=head->key;
		temp_ptr=head;
		while (temp_ptr != NULL)
		{
			if (min >=temp_ptr->key) 
			{
				pos_ptr=new Node();
				pos_ptr=temp_ptr;
				min=temp_ptr->key;
			}
			temp_ptr=temp_ptr->right;
		}
		strvalue->vssize=0;
		strvalue->push_back(pos_ptr->value);
	}
	return min;
}

IVectorString * PriorityQueue3 :: lowestValues()
{
	return(strvalue);
}

void PriorityQueue3 :: dequeue ()
{  
   flag=1;
   Node *ptr=new Node();

   int min=lowestKey();
   
   for (int i=0; i<(pos_ptr->linkno)-1; i++)
   {
	     pos_ptr->link[i]->right=pos_ptr->link[i+1];
	     pos_ptr->link[i+1]->left=pos_ptr->link[i];
   }
  
   Node *prev = new Node();
   Node *next=new Node();

   if (head == pos_ptr)
   {
	   if(pos_ptr->linkno >0)
	   {
		   next=head->right;
		   pos_ptr->link[(pos_ptr->linkno)-1]->right=next;
		   if (next != NULL)
		   next->left=pos_ptr->link[(pos_ptr->linkno)-1];
	       head=pos_ptr->link[0];
	       head->left=NULL;
	   }
	   else
	   {
		   head=head->right;
		   if (head != NULL)
		   head->left=NULL;
	   }
   }
   else
   {
	   if (pos_ptr->linkno >0)
	   {
	      prev=pos_ptr->left;
		  pos_ptr->link[0]->left=prev;
		  if (prev != NULL)
		  prev->right=pos_ptr->link[0];

		  next=pos_ptr->right;
		  pos_ptr->link[(pos_ptr->linkno)-1]->right=next;
		  if (next != NULL)
		  next->left=pos_ptr->link[(pos_ptr->linkno)-1];
	   }
	   else
	   {
		   prev=pos_ptr->left;
		   next=pos_ptr->right;
		   prev->right=next;
		   if (next != NULL)
		   next->left=prev;
	   }   
   }
   /*
   Node *stack[50];int top=0;

   Node *temp_ptr=new Node();
   temp_ptr=head;

   while (temp_ptr != NULL)
   {
	   stack[top++]=temp_ptr;
	   temp_ptr=temp_ptr->right;
   }

   //sort1(stack,top);

   for (int i=0;i<top-1;i++)
	{
		for (int j=i+1;j<top;j++)
		{
			if (stack[i]->linkno < stack[j]->linkno)
			{
				Node *temp=new Node ();
				temp=stack[i];
				stack[i]=stack[j];
				stack[j]=temp;
			}
			else if (stack[i]->linkno == stack[j]->linkno)
			{
				if (stack[i]->key < stack[j]->key)
				{
					Node *temp=new Node ();
					temp=stack[i];
					stack[i]=stack[j];
					stack[j]=temp;
				}
			}

		}
	}

   Node *save[50];
	int save_size=0;
	int x=top-1;
	while ( x>0 )
	{
		if (stack[x]->linkno==stack[x-1]->linkno)
		{
			stack[x]->link[stack[x]->linkno++]=stack[x-1];
			save[save_size++]=stack[x];
			x=x-2;
		}
		else
		{
			save[save_size++]=stack[x];
			x--;
		}
	}
	if (x ==0)
		save[save_size++]=stack[x];
	top=0;
	for (int j=save_size-1;j>=0;j--)
	{
		stack[top++]=save[j];
	}
	for (int i=0; i<top-1;i++)
	{
		stack[i]->right=stack[i+1];
		stack[i+1]->left=stack[i];
	}
	stack[top-1]->right=NULL;
	stack[0]->left=NULL;
	if (top>=0)
	head=stack[0];


	*/
	 /*  
   
   int min=lowestKey();

   Node *temp_ptr[50000];
   int size=0;
   int i;
   for (i=0;i<pos;i++)
   {
	   temp_ptr[size++]=stk[i];
   }

   if (i == pos)
   {
       int j=stk[i]->linkno;
	   for (int k=0; k<j ; k++)
	   {
		   temp_ptr[size++]=stk[i]->link[k];
	   }
   }

   for (int i=pos+1; i<stack_size;i++)
   {
	   temp_ptr[size++]=stk[i];
   }
   
   stack_size=0;
   for (int i=0; i<size;i++)
   {
	   stk[stack_size++]=temp_ptr[i];
   } */
   queue_size--; 
}

size_t PriorityQueue3 :: size ()
{
	return queue_size;
}