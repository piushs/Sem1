#pragma once

#include "Interfaces02.h"
#include "VectorString.h"

class Qelement 
{
public:
	Qelement()
	{
	   value=new VectorString();
	   
	}
	~Qelement(){};
	int key;
	Qelement *right;

	VectorString *value;
};



class PriorityQueue2 : public IPriorityQueue
{

public :
	Qelement *q[50000];
	
	int queue_size;
	PriorityQueue2() 
	{ 
		queue_size =0; 
		for (int i=0; i<50000; i++)
	    {
		   visited[i]=0;
		 //  store[i]=new Qelement();
	    }
		
	};
    ~PriorityQueue2() {};
	int visited[50000];

	void enqueue(IKeyValue * key_value);
	void merge(IPriorityQueue * input_queue);
    IVectorKeyValue* returnSorted();
	int lowestKey();
	IVectorString * lowestValues();
    void dequeue();
	size_t size();
};