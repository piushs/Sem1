#include "PriorityQueue4.h"
#include "VectorKeyValue.h"
#include "KeyValue.h"
#include "VectorString.h"
#include "PriorityQueue4.h"
#include <iostream>


void PriorityQueue4 :: merge (IPriorityQueue * input_queue)
{
	/*
	Element *ptr1, *ptr2;
	Element *prev=new Element();
	PriorityQueue4 *temp_ptr = new PriorityQueue4();
	temp_ptr=(PriorityQueue4 *)input_queue;
	
	ptr1=new Element();
	ptr2=new Element();

	ptr1=head;
	ptr2=temp_ptr->head;

	if (ptr1->key > ptr2->key)
		prev=ptr2;
	else
	{
		Element *ptr3=new Element();
		ptr3=ptr2;
		ptr2=ptr1;
		ptr1=ptr3;
	}
	head=ptr2;
	while (ptr2 != NULL)
	{
		if (ptr1->key > ptr2->key)
		{
			prev=ptr2;
			ptr2=ptr2->right;
		}
		else
		{
			Element *temp;
			temp=ptr1->right;
			prev->right=ptr1;
			ptr1->right=ptr2;

			if (temp == NULL)
			{
				ptr2->right=temp;
				break;
			}

			if (temp->key < ptr2->key)
			{
				Element *ptr3=new Element();
				ptr3=ptr2;
			    ptr2=temp;
				ptr1=ptr3;
			}
			else
				ptr1=temp;
		}
	}
	prev->right=ptr1;*/

	PriorityQueue4 *temp_ptr=new PriorityQueue4();
	temp_ptr=(PriorityQueue4*) input_queue;
	if (min->key > temp_ptr->min->key)
		min=temp_ptr->min;

	tail->right=temp_ptr->head;
}

IVectorKeyValue * PriorityQueue4 :: returnSorted()
{
	return NULL;
}


void PriorityQueue4 :: enqueue (IKeyValue  * key_value)
{
	/*
	Element *node=new Element();
	Element *temp_ptr=new Element();
	Element *prev = new Element();

	node->key=key_value->getKey();
	node->value=key_value->getValue();
	node->right = NULL;
	node->linkno=0;
	queue_size++;
	if (head == NULL)
	{
		head=node;
	}
	else
	{
		temp_ptr=head;
		while (temp_ptr != NULL)
		{
			if (temp_ptr->key > node->key)
			{
				if (temp_ptr == head)
				{
					node->right=head;
					head=node;
				}
				else
				{
					Element *swap = new Element();
					swap=prev->right;
					prev->right=node;
					node->right=swap;
				}
				break;
			}
			else
			{
				prev=temp_ptr;
				temp_ptr=temp_ptr->right;
			}
		}
		if (temp_ptr == NULL)
		{
			prev->right=node;
		}
	} */

	Element *node=new Element();
	Element *temp_ptr=new Element();
	Element *prev = new Element();

	node->key=key_value->getKey();
	node->value=key_value->getValue();
	node->right = NULL;
	node->linkno=0;
	queue_size++;
	if (head == NULL)
	{
		min=node;
		tail=node;
		head=node;
	}
	else
	{
		if (min->key > node->key)
			min=node;
		head->right=node;
		tail=node;
	}
}


int  PriorityQueue4 :: lowestKey ()
{
	return min->key;
}

IVectorString * PriorityQueue4 :: lowestValues()
{
	strval->vssize=0;
	strval->push_back(min->value);
//	dequeue();
	return(strval);
}

void PriorityQueue4 :: dequeue ()
{
   Element *stk[20] ;
   int top=0;
   
   int stk_size=0;
   Element *temp_ptr=new Element();

   for (int i=0; i<(head->linkno)-1;i++)
   {
	   head->link[i]->right=head->link[i+1];
   }

   if (head->linkno == 0)
		temp_ptr=head;
   else
		temp_ptr=head->link[0];

   while (temp_ptr != NULL)
   {
	   int i;
	   for (i=top-1; i>0 ;i--)
	   {
			if(stk[i]->linkno == stk[i-1]->linkno)
			{
				stk[i-1]->link[stk[i-1]->linkno++]=stk[i];
			}
			else
			{
				break;
			}
		}
		top=i+1;
	    stk[top++] = temp_ptr;
	
	    temp_ptr=temp_ptr->right;
   }
   for (int i=0; i<top-1;i++)
   {
	   stk[i]->right=stk[i+1];
   }
   stk[top-1]->right=NULL;
   head=stk[0];
   //queue_size--;
}

size_t PriorityQueue4 :: size ()
{
	return queue_size;
}