#pragma once

#include "Interfaces02.h"
#include "KeyValue.h"
#include "VectorString.h"

class VectorKeyValue:public IVectorKeyValue {
public:
  size_t vksize;
  KeyValue *vkvalue;
  KeyValue *addr1[10000];
  int init;
  VectorKeyValue() 
  {
     vksize=0;
	 init=0;
	 for (int i=0 ; i< 10000; i++)
	 {
	   addr1[i]=NULL;
	 }
  }
  ~VectorKeyValue() {}
  void push_back(IKeyValue * item);
  void pop_back();
  IKeyValue * get(int index);
  void set(int index, IKeyValue * item);
  size_t size();
};
