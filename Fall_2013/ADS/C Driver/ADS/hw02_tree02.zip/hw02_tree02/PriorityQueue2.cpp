#include "PriorityQueue2.h"
#include <iostream>

void PriorityQueue2 :: merge (IPriorityQueue * input_queue)
{
	std :: cout << "";
}

void PriorityQueue2 :: enqueue (IKeyValue  * key_value)
{
	Qelement *temp_ptr=new Qelement();
	VectorString *values =new VectorString();

	
	temp_ptr->key=key_value->getKey();
	values = temp_ptr->value;
	values->push_back(key_value->getValue());

	
	int parent=((queue_size+1)/2) -1;
	Qelement *swap = new Qelement();

	if (parent < 0)
	{
		q[queue_size++]=temp_ptr;
		visited[temp_ptr->key]=1;
	}
	else
	{
		if (visited[temp_ptr->key] == 0)
		{
			q[queue_size++]=temp_ptr;
		
			int child=queue_size-1;
			while (parent >=0)
			{
				if (q[child]->key < q[parent]->key)
				{
					swap=q[parent];
					q[parent]=q[child];
					q[child]=swap;
			
				}

				child--;
				if (((child+1)/2-1)!= parent)
				{
				    child=parent;
					parent=(child+1)/2-1;
				}
			}
			visited[temp_ptr->key]=1;
		}
		else
		{
		
			for (int i=0; i< queue_size;i++)
			{
				if (q[i]->key == temp_ptr->key)
				{
					q[i]->value->push_back(key_value->getValue());
					break;
				}
			} 
			
		} 
	}
}


IVectorKeyValue * PriorityQueue2 :: returnSorted()
{
	return NULL;
}

int  PriorityQueue2 :: lowestKey ()
{
	return (q[0]->key);
}

IVectorString * PriorityQueue2 :: lowestValues()
{
	return(q[0]->value);
}

void PriorityQueue2 :: dequeue ()
{

	q[0]=q[queue_size-1];

	Qelement *replace = new Qelement();
	Qelement *swap = new Qelement();

	queue_size--;
	int top=0;
	int child1=(2*top +1);
	int child2=(2*top+2);
	int index;

	while (child1 < queue_size || child2< queue_size)
	{
		if (child1 < queue_size && child2 > queue_size)
		{
			index=child1;
			replace=q[child1];
		}
		if (child2 < queue_size && child1 > queue_size)
		{
			index=child2;
			replace=q[child2];
		}
		if (q[child1]->key < q[child2]->key)
		{
			index=child1;
			replace=q[child1];
		}
		else
		{
			index=child2;
			replace=q[child2];
		}

		if (replace->key < q[top]->key)
		{
			swap=replace;
			q[index]=q[top];
			q[top]=swap;
			top=index;
		}
		child1=2*index+1;
		child2=2*index+2;
	}
}

size_t PriorityQueue2 :: size ()
{
	return queue_size;
}